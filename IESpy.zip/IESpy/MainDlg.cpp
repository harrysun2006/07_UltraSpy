// MainDlg.cpp: implementation of the CMainDlg class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "IESpy.h"
#include "MainDlg.h"
#include "IESeeker.h"
#include "Test.h"

CMainDlg* g_pMainWin = 0;

using namespace seeker;

LRESULT CMainDlg::OnInitDialog(
	UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	CenterWindow();
	HRESULT hr = S_OK;
	bHandled = FALSE;
	return TRUE;
}

LRESULT CMainDlg::OnDestroy(
	UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	PostQuitMessage(0);
	CIESeeker::Instance()->Stop();
	return 0;
}

LRESULT CMainDlg::OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	DestroyWindow();
	return 0;
}

LRESULT CMainDlg::OnStart(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	CIESeeker::Instance()->Start();
	return 0;
}

LRESULT CMainDlg::OnStop(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	CIESeeker::Instance()->Stop();
	return 0;
}

LRESULT CMainDlg::OnTest(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	REDIR_OUT2LOG;
	test4();
	REDIR_OUT2OUT;
	return 0;
}

void CMainDlg::Log(LPCTSTR psz)
{
	//CString strDebug;
	//strDebug.Format("%s\n", psz);
	
	CWindow wndEdit = GetDlgItem(IDC_LOG);
	int len = wndEdit.GetWindowTextLength();
	wndEdit.SendMessage(EM_SETSEL, len, len);
	wndEdit.SendMessage(EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>(psz));
	//wndEdit.SendMessage(EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>(strDebug.GetBuffer(strDebug.GetLength())));
}
