// IESeeker.h: interface for the CIESeeker class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(IESEEKER__INCLUDED_)
#define IESEEKER__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#include <mshtml.h>
#include <map>

using namespace std;

namespace seeker {
typedef struct EVENT_SINK {
	LPUNKNOWN pUnkSrc;
	LPUNKNOWN pUnkSink;
	DWORD dwCookie;
	IID iid;
} EVENT_SINK;

typedef EVENT_SINK* LPEVENT_SINK;
typedef map<LPVOID, EVENT_SINK> EVENT_SINK_MAP;
typedef pair<LPVOID, EVENT_SINK> EVENT_SINK_PAIR;

class CIESeeker
{
public:
	static CIESeeker* Instance()
	{
		if(_instance == NULL) _instance = new CIESeeker();
		return _instance;
	}
	void Start();
	void Stop();
	void AddSink(EVENT_SINK eventSink);
protected:
	void RemoveAllSinks();
	void RemoveSink(LPVOID pSink, EVENT_SINK pEventSink);
private:
	CIESeeker(void){};
	virtual ~CIESeeker(void){};
	static CIESeeker* _instance;
	EVENT_SINK_MAP m_eventSinks;
};
}
#endif // !defined(IESEEKER__INCLUDED_)