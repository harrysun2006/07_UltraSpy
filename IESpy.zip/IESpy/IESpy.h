#if !defined(IESPY__INCLUDED_)
#define IESPY__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

#endif // !defined(IESPY__INCLUDED_)