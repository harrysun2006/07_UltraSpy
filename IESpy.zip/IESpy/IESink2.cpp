#include "stdafx.h"
#include "IESpy.h"
#include "IESink2.h"
#include <fstream>
#include <exdispid.h>
#include <mshtml.h>
#include <afxctl.h>

using namespace std;

BEGIN_DISPATCH_MAP(CIESink2, CCmdTarget)
	DISP_FUNCTION_ID(CIESink2, "BeforeNavigate2", DISPID_BEFORENAVIGATE2, OnBeforeNavigate2, VT_EMPTY, VTS_DISPATCH VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PBOOL)
	DISP_FUNCTION_ID(CIESink2, "NavigateComplete2", DISPID_NAVIGATECOMPLETE2, OnNavigateComplete2, VT_EMPTY, VTS_DISPATCH VTS_PVARIANT)
	DISP_FUNCTION_ID(CIESink2, "StatusTextChange", DISPID_STATUSTEXTCHANGE, OnStatusTextChange, VT_EMPTY, VTS_BSTR)
	DISP_FUNCTION_ID(CIESink2, "ProgressChange", DISPID_PROGRESSCHANGE, OnProgressChange, VT_EMPTY, VTS_I4 VTS_I4)
	DISP_FUNCTION_ID(CIESink2, "DocumentComplete", DISPID_DOCUMENTCOMPLETE, OnDocumentComplete, VT_EMPTY, VTS_DISPATCH VTS_PVARIANT)
	DISP_FUNCTION_ID(CIESink2, "DownloadBegin", DISPID_DOWNLOADBEGIN, OnDownloadBegin, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION_ID(CIESink2, "DownloadComplete", DISPID_DOWNLOADCOMPLETE, OnDownloadComplete, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION_ID(CIESink2, "CommandStateChange", DISPID_COMMANDSTATECHANGE, OnCommandStateChange, VT_EMPTY, VTS_I4 VTS_BOOL)
	DISP_FUNCTION_ID(CIESink2, "NewWindow2", DISPID_NEWWINDOW2, OnNewWindow2, VT_EMPTY, VTS_PDISPATCH VTS_PBOOL)
	DISP_FUNCTION_ID(CIESink2, "NewWindow3", DISPID_NEWWINDOW3, OnNewWindow3, VT_EMPTY, VTS_PDISPATCH VTS_PBOOL VTS_I4 VTS_BSTR VTS_BSTR)
	DISP_FUNCTION_ID(CIESink2, "TitleChange", DISPID_TITLECHANGE, OnTitleChange, VT_EMPTY, VTS_BSTR)
	DISP_FUNCTION_ID(CIESink2, "PropertyChange", DISPID_PROPERTYCHANGE, OnPropertyChange, VT_EMPTY, VTS_BSTR)
	DISP_FUNCTION_ID(CIESink2, "Quit", DISPID_QUIT, OnQuit, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION_ID(CIESink2, "OnQuit", DISPID_ONQUIT, OnQuit, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION_ID(CIESink2, "OnVisible", DISPID_ONVISIBLE, OnVisible, VT_EMPTY, VTS_BOOL)
	DISP_FUNCTION_ID(CIESink2, "OnToolBar", DISPID_ONTOOLBAR, OnToolBar, VT_EMPTY, VTS_BOOL)
	DISP_FUNCTION_ID(CIESink2, "OnMenuBar", DISPID_ONMENUBAR, OnMenuBar, VT_EMPTY, VTS_BOOL)
	DISP_FUNCTION_ID(CIESink2, "OnStatusBar", DISPID_ONSTATUSBAR, OnStatusBar, VT_EMPTY, VTS_BOOL)
	DISP_FUNCTION_ID(CIESink2, "OnFullScreen", DISPID_ONFULLSCREEN, OnFullScreen, VT_EMPTY, VTS_BOOL)
	DISP_FUNCTION_ID(CIESink2, "OnTheaterMode", DISPID_ONTHEATERMODE, OnTheaterMode, VT_EMPTY, VTS_BOOL)
	DISP_FUNCTION_ID(CIESink2, "WindowSetResizable", DISPID_WINDOWSETRESIZABLE, OnWindowSetResizable, VT_EMPTY, VTS_BOOL)
	DISP_FUNCTION_ID(CIESink2, "WindowSetLeft", DISPID_WINDOWSETLEFT, OnWindowSetLeft, VT_EMPTY, VTS_I4)
	DISP_FUNCTION_ID(CIESink2, "WindowSetTop", DISPID_WINDOWSETTOP, OnWindowSetTop, VT_EMPTY, VTS_I4)
	DISP_FUNCTION_ID(CIESink2, "WindowSetWidth", DISPID_WINDOWSETWIDTH, OnWindowSetWidth, VT_EMPTY, VTS_I4)
	DISP_FUNCTION_ID(CIESink2, "WindowSetHeight", DISPID_WINDOWSETHEIGHT, OnWindowSetHeight, VT_EMPTY, VTS_I4)
	DISP_FUNCTION_ID(CIESink2, "WindowClosing", DISPID_WINDOWCLOSING, OnWindowClosing, VT_EMPTY, VTS_BOOL VTS_PBOOL)
	DISP_FUNCTION_ID(CIESink2, "ClientToHostWindow", DISPID_CLIENTTOHOSTWINDOW, OnClientToHostWindow, VT_EMPTY, VTS_PI4 VTS_PI4)
	DISP_FUNCTION_ID(CIESink2, "SetSecureLockIcon", DISPID_SETSECURELOCKICON, OnSetSecureLockIcon, VT_EMPTY, VTS_I4)
	DISP_FUNCTION_ID(CIESink2, "FileDownload", DISPID_FILEDOWNLOAD, OnFileDownload, VT_EMPTY, VTS_PBOOL)
	DISP_FUNCTION_ID(CIESink2, "NavigateError", DISPID_NAVIGATEERROR, OnNavigateError, VT_EMPTY, VTS_DISPATCH VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PBOOL)
	DISP_FUNCTION_ID(CIESink2, "PrintTemplateInstantiation", DISPID_PRINTTEMPLATEINSTANTIATION, OnPrintTemplateInstantiation, VT_EMPTY, VTS_DISPATCH)
	DISP_FUNCTION_ID(CIESink2, "PrintTemplateTeardown", DISPID_PRINTTEMPLATETEARDOWN, OnPrintTemplateTeardown, VT_EMPTY, VTS_DISPATCH)
	DISP_FUNCTION_ID(CIESink2, "UpdatePageStatus", DISPID_UPDATEPAGESTATUS, OnUpdatePageStatus, VT_EMPTY, VTS_DISPATCH VTS_PVARIANT VTS_PVARIANT)
	DISP_FUNCTION_ID(CIESink2, "PrivacyImpactedStateChange", DISPID_PRIVACYIMPACTEDSTATECHANGE, OnPrivacyImpactedStateChange, VT_EMPTY, VTS_BOOL)
END_DISPATCH_MAP()

void CIESink2::EnumDocument(IHTMLDocument2 *pIHTMLDocument2)
{
	HRESULT hr;
	USES_CONVERSION;

	if (!pIHTMLDocument2) return;

	CComBSTR bstrTitle, bstrURL, bstrHTML;
	pIHTMLDocument2->get_title(&bstrTitle);	//ȡ���ĵ�����
	pIHTMLDocument2->get_URL(&bstrURL);

	CComQIPtr <IHTMLElement> spBody;
	hr = pIHTMLDocument2->get_body(&spBody);
	if (FAILED(hr)) return;
	
	CComQIPtr <IHTMLElement> spHTML;
	hr = spBody->get_parentElement(&spHTML);
	if (FAILED(hr)) return;
	spHTML->get_outerHTML(&bstrHTML);
	
	cout << _T("CIESink2::OnDocumentComplete.Title: ") << (bstrTitle ? OLE2CT(bstrTitle) : _T("")) << endl;
	cout << _T("CIESink2::OnDocumentComplete.URL: ") << (bstrURL ? OLE2CT(bstrURL) : _T("")) << endl;
}

// DWebBrowserEvents2 methods
// Fired before navigate occurs in the given WebBrowser (window or frameset element). 
// The processing of this navigation may be modified.
void CIESink2::OnBeforeNavigate2(LPDISPATCH pDisp,
			 				   VARIANT* URL,
							   VARIANT* Flags,
							   VARIANT* TargetFrameName,
							   VARIANT* PostData,
							   VARIANT* Headers,
							   VARIANT_BOOL* Cancel)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnBeforeNavigate2" << endl;
	REDIR_OUT2OUT
}

// Fired when the document being navigated to becomes visible and enters the navigation stack.
void CIESink2::OnNavigateComplete2(LPDISPATCH pDisp, VARIANT* URL)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnNavigateComplete" << endl;
	REDIR_OUT2OUT
}

// Statusbar text changed.
void CIESink2::OnStatusTextChange(BSTR Text)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnStatusTextChange" << endl;
	REDIR_OUT2OUT
}

// Fired when download progress is updated.
void CIESink2::OnProgressChange(long Progress, long ProgressMax)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnProgressChange" << endl;
	REDIR_OUT2OUT
}

// Fired when the document being navigated to reaches ReadyState_Complete.
void CIESink2::OnDocumentComplete(LPDISPATCH pDisp, VARIANT *pvarURL)
{
	REDIR_OUT2LOG;
	cout << "CIESink2::OnDocumentComplete" << endl;
	CComQIPtr<IWebBrowser2> pWebBrowser2 = pDisp;
	HRESULT hr = S_FALSE;
	if(pWebBrowser2)
	{
		CComPtr<IDispatch> spDispDoc;
		hr = pWebBrowser2->get_Document(&spDispDoc);
		if (SUCCEEDED(hr) && spDispDoc) 
		{
			CComQIPtr<IHTMLDocument2> spDocument = spDispDoc;
			EnumDocument(spDocument);
		}
	}
	REDIR_OUT2OUT;
}

// Download of a page started.
void CIESink2::OnDownloadBegin()
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnDownloadBegin" << endl;
	REDIR_OUT2OUT
}

// Download of page complete.
void CIESink2::OnDownloadComplete()
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnDownloadComplete" << endl;
	REDIR_OUT2OUT
}

// The enabled state of a command changed.
void CIESink2::OnCommandStateChange(long Command, BOOL Enable)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnCommandStateChange(" << Command << ")" << endl;
	REDIR_OUT2OUT
}

// A new, hidden, non-navigated WebBrowser window is needed.
void CIESink2::OnNewWindow2(LPDISPATCH* ppDisp, VARIANT_BOOL* Cancel)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnNewWindow2" << endl;
	REDIR_OUT2OUT
}

// A new, hidden, non-navigated WebBrowser window is needed.
void CIESink2::OnNewWindow3(LPDISPATCH* ppDisp, VARIANT_BOOL* Cancel, unsigned long dwFlags, 
	BSTR bstrUrlContext, BSTR bstrUrl)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnNewWindow3" << endl;
	REDIR_OUT2OUT
}

// Document title changed.
void CIESink2::OnTitleChange(BSTR Text)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnTitleChange" << endl;
	REDIR_OUT2OUT
}

// Fired when the PutProperty method has been called.
void CIESink2::OnPropertyChange(BSTR szProperty)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnPropertyChange" << endl;
	REDIR_OUT2OUT
}

// Fired when application is quiting.
void CIESink2::OnQuit()
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnQuit" << endl;
	REDIR_OUT2OUT
}

// Fired when the window should be shown/hidden.
void CIESink2::OnVisible(VARIANT_BOOL Visible)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnVisible" << endl;
	REDIR_OUT2OUT
}

// Fired when the toolbar  should be shown/hidden.
void CIESink2::OnToolBar(VARIANT_BOOL ToolBar)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnToolBar" << endl;
	REDIR_OUT2OUT
}

// Fired when the menubar should be shown/hidden.
void CIESink2::OnMenuBar(VARIANT_BOOL MenuBar)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnMenuBar" << endl;
	REDIR_OUT2OUT
}

// Fired when the statusbar should be shown/hidden.
void CIESink2::OnStatusBar(VARIANT_BOOL StatusBar)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnStatusBar" << endl;
	REDIR_OUT2OUT
}

// Fired when fullscreen mode should be on/off.
void CIESink2::OnFullScreen(VARIANT_BOOL FullScreen)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnFullScreen" << endl;
	REDIR_OUT2OUT
}

// Fired when theater mode should be on/off.
void CIESink2::OnTheaterMode(VARIANT_BOOL TheaterMode)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnTheaterMode" << endl;
	REDIR_OUT2OUT
}

// Fired when the host window should allow/disallow resizing.
void CIESink2::OnWindowSetResizable(VARIANT_BOOL Resizable)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnWindowSetResizable" << endl;
	REDIR_OUT2OUT
}

// Fired when the host window should change its Left coordinate.
void CIESink2::OnWindowSetLeft(long Left)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnWindowSetLeft" << endl;
	REDIR_OUT2OUT
}

// Fired when the host window should change its Top coordinate.
void CIESink2::OnWindowSetTop(long Top)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnWindowSetTop" << endl;
	REDIR_OUT2OUT
}

// Fired when the host window should change its width.
void CIESink2::OnWindowSetWidth(long Width)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnWindowSetWidth" << endl;
	REDIR_OUT2OUT
}

// Fired when the host window should change its height.
void CIESink2::OnWindowSetHeight(long Height)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnWindowSetHeight" << endl;
	REDIR_OUT2OUT
}

// Fired when the WebBrowser is about to be closed by script.
void CIESink2::OnWindowClosing(VARIANT_BOOL IsChildWindow, VARIANT_BOOL* Cancel)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnWindowClosing" << endl;
	REDIR_OUT2OUT
}

// Fired to request client sizes be converted to host window sizes.
void CIESink2::OnClientToHostWindow(long* CX, long* CY)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnClientToHostWindow" << endl;
	REDIR_OUT2OUT
}

// Fired to indicate the security level of the current web page contents.
void CIESink2::OnSetSecureLockIcon(long SecureLockIcon)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnSetSecureLockIcon" << endl;
	REDIR_OUT2OUT
}

// Fired to indicate the File Download dialog is opening.
void CIESink2::OnFileDownload(VARIANT_BOOL* Cancel)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnFileDownload" << endl;
	REDIR_OUT2OUT
}

// Fired when a binding error occurs (window or frameset element).
void CIESink2::OnNavigateError(LPDISPATCH pDisp, VARIANT* URL, VARIANT* Frame, 
	VARIANT* StatusCode, VARIANT_BOOL* Cancel)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnNavigateError" << endl;
	REDIR_OUT2OUT
}

// Fired when a print template is instantiated.
void CIESink2::OnPrintTemplateInstantiation(LPDISPATCH pDisp)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnPrintTemplateInstantiation" << endl;
	REDIR_OUT2OUT
}

// Fired when a print template destroyed."
void CIESink2::OnPrintTemplateTeardown(LPDISPATCH pDisp)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnPrintTemplateTeardown" << endl;
	REDIR_OUT2OUT
}

// Fired when a page is spooled. When it is fired can be changed by a custom template.
void CIESink2::OnUpdatePageStatus(LPDISPATCH pDisp, VARIANT* nPage, VARIANT* fDone)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnUpdatePageStatus" << endl;
	REDIR_OUT2OUT
}

// Fired when the global privacy impacted state changes.
void CIESink2::OnPrivacyImpactedStateChange(VARIANT_BOOL bImpacted)
{
	REDIR_OUT2LOG
	cout << "CIESink2::OnPrivacyImpactedStateChange" << endl;
	REDIR_OUT2OUT
}
