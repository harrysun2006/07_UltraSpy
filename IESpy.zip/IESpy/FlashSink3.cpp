#include "stdafx.h"
#include "IESpy.h"
#include "FlashSink3.h"
#include <fstream>
#include <afxctl.h>

using namespace std;

STDMETHODIMP CFlashSink3::QueryInterface(const struct _GUID &iid,void ** ppv)
{
	*ppv = this;
	return S_OK;
}

ULONG CFlashSink3::AddRef(void)
{
	return S_OK;
}

ULONG CFlashSink3::Release(void)
{
	return S_OK;
}

STDMETHODIMP CFlashSink3::Invoke(DISPID id, REFIID riid, LCID lcid, WORD wFlags, 
	DISPPARAMS* pdp, VARIANT* pvarResult, EXCEPINFO* pExcepInfo, UINT* puArgErr)
{
	REDIR_OUT2LOG;
	/*
	cout
		<< _T("CFlashSink>>Invoke: ")
		<< _T("dispID = ") << id
		<< _T(", pParams = [");
	for (int i = 0; i < pdp->cArgs; i++)
	{
		cout << pdp->rgvarg[i].bstrVal << _T(", ");
	}
	cout << "]" << endl;
	*/
	if (!pdp) return E_INVALIDARG;

	switch (id)
	{
		case DISPID_ONREADYSTATECHANGE:
			ATLASSERT(pdp->cArgs == 1);
			OnReadyStateChange(pdp->rgvarg[0].lVal);
		break;

		case DISPID_ONPROGRESS:
			ATLASSERT(pdp->cArgs == 1);
			OnProgress(pdp->rgvarg[0].lVal);
		break;

		case DISPID_FSCOMMAND:
			ATLASSERT(pdp->cArgs == 2);
			OnFSCommand(pdp->rgvarg[1].bstrVal, pdp->rgvarg[0].bstrVal);
		break;

		case DISPID_FLASHCALL:
			ATLASSERT(pdp->cArgs == 1);
			OnFlashCall(pdp->rgvarg[0].bstrVal);
		break;

		case DISPID_GOTFOCUS:
			ATLASSERT(pdp->cArgs == 0);
			OnGotFocus();
		break;

		case DISPID_LOSTFOCUS:
			ATLASSERT(pdp->cArgs == 0);
			OnLostFocus();
		break;

		default:
			cout
				<< _T("CFlashSink::Invoke unknown event: ")
				<< _T("dispID = ") << id
				<< _T(", pParams = [");
			for (int i = 0; i < pdp->cArgs; i++)
			{
				cout << pdp->rgvarg[i].bstrVal << _T(", ");
			}
			cout << "]" << endl;
		break;
	}	
	REDIR_OUT2OUT;
	return S_OK;
}

void CFlashSink3::OnReadyStateChange(long newState)
{
	REDIR_OUT2LOG
	cout << "CFlashSink3::OnReadyStateChange: " << newState << endl;
	REDIR_OUT2OUT
}

void CFlashSink3::OnProgress(long percentDone)
{
	REDIR_OUT2LOG
	cout << "CFlashSink3::OnProgress: " << percentDone << endl;
	REDIR_OUT2OUT
}

void CFlashSink3::OnFSCommand(BSTR command, BSTR args)
{
	REDIR_OUT2LOG
	cout << "CFlashSink3::OnFSCommand: " << command << _T("(") << args << _T(")") << endl;
	REDIR_OUT2OUT
}

void CFlashSink3::OnFlashCall(BSTR request)
{
	REDIR_OUT2LOG
	cout << "CFlashSink3::OnFlashCall: " << request << endl;
	REDIR_OUT2OUT
}

void CFlashSink3::OnGotFocus()
{
	REDIR_OUT2LOG
	cout << "CFlashSink3::OnGotFocus" << endl;
	REDIR_OUT2OUT
}

void CFlashSink3::OnLostFocus()
{
	REDIR_OUT2LOG
	cout << "CFlashSink3::OnLostFocus" << endl;
	REDIR_OUT2OUT
}