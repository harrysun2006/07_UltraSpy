//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IESpy.rc
//
#define IDS_PROJNAME                    100
#define IDR_PassthruAPP                 100
#define IDD_MAINDLG                     201
#define IDC_START                       202
#define IDC_STOP                        203
#define IDC_LOG                         204
#define IDC_TEST                        205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         205
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
