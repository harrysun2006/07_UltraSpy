#include "stdafx.h"
#include "IESpy.h"
#include "FlashSink.h"
#include <fstream>

using namespace std;

STDMETHODIMP CFlashSink::Invoke(DISPID id, REFIID riid, LCID lcid, WORD wFlags, 
	DISPPARAMS* pdp, VARIANT* pvarResult, EXCEPINFO* pExcepInfo, UINT* puArgErr)
{
	REDIR_OUT2LOG;
	/*
	cout
		<< _T("CFlashSink>>Invoke: ")
		<< _T("dispID = ") << id
		<< _T(", pParams = [");
	for (int i = 0; i < pdp->cArgs; i++)
	{
		cout << pdp->rgvarg[i].bstrVal << _T(", ");
	}
	cout << "]" << endl;
	*/
	if (!pdp) return E_INVALIDARG;

	switch (id)
	{
		case DISPID_ONREADYSTATECHANGE:
			ATLASSERT(pdp->cArgs == 1);
			OnReadyStateChange(pdp->rgvarg[0].lVal);
		break;

		case DISPID_ONPROGRESS:
			ATLASSERT(pdp->cArgs == 1);
			OnProgress(pdp->rgvarg[0].lVal);
		break;

		case DISPID_FSCOMMAND:
			ATLASSERT(pdp->cArgs == 2);
			OnFSCommand(pdp->rgvarg[1].bstrVal, pdp->rgvarg[0].bstrVal);
		break;

		case DISPID_FLASHCALL:
			ATLASSERT(pdp->cArgs == 1);
			OnFlashCall(pdp->rgvarg[0].bstrVal);
		break;

		case DISPID_GOTFOCUS:
			ATLASSERT(pdp->cArgs == 0);
			OnGotFocus();
		break;

		case DISPID_LOSTFOCUS:
			ATLASSERT(pdp->cArgs == 0);
			OnLostFocus();
		break;

		default:
			cout
				<< _T("CFlashSink::Invoke unknown event: ")
				<< _T("dispID = ") << id
				<< _T(", pParams = [");
			for (int i = 0; i < pdp->cArgs; i++)
			{
				cout << pdp->rgvarg[i].bstrVal << _T(", ");
			}
			cout << "]" << endl;
		break;
	}	
	REDIR_OUT2OUT;
	return S_OK;
}

void CFlashSink::OnReadyStateChange(long newState)
{
	cout << "CFlashSink::OnReadyStateChange: " << newState << endl;
}

void CFlashSink::OnProgress(long percentDone)
{
	cout << "CFlashSink::OnProgress: " << percentDone << endl;
}

void CFlashSink::OnFSCommand(BSTR command, BSTR args)
{
	cout << "CFlashSink::OnFSCommand: " << command << _T("(") << args << _T(")") << endl;
}

void CFlashSink::OnFlashCall(BSTR request)
{
	cout << "CFlashSink::OnFlashCall: " << request << endl;
}

void CFlashSink::OnGotFocus()
{
	cout << "CFlashSink::OnGotFocus" << endl;
}

void CFlashSink::OnLostFocus()
{
	cout << "CFlashSink::OnLostFocus" << endl;
}