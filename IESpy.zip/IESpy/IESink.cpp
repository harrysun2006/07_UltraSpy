#include "stdafx.h"
#include "IESpy.h"
#include "IESink.h"
#include <fstream>
#include <exdispid.h>
#include <mshtml.h>

using namespace std;

void CIESink::EnumDocument(IHTMLDocument2 *pIHTMLDocument2)
{
	HRESULT hr;
	USES_CONVERSION;

	if (!pIHTMLDocument2) return;

	CComBSTR bstrTitle, bstrURL, bstrHTML;
	pIHTMLDocument2->get_title(&bstrTitle);	//ȡ���ĵ�����
	pIHTMLDocument2->get_URL(&bstrURL);

	CComQIPtr <IHTMLElement> spBody;
	hr = pIHTMLDocument2->get_body(&spBody);
	if (FAILED(hr)) return;
	
	CComQIPtr <IHTMLElement> spHTML;
	hr = spBody->get_parentElement(&spHTML);
	if (FAILED(hr)) return;
	spHTML->get_outerHTML(&bstrHTML);
	
	cout << _T("CIESink::OnDocumentComplete.Title: ") << (bstrTitle ? OLE2CT(bstrTitle) : _T("")) << endl;
	cout << _T("CIESink::OnDocumentComplete.URL: ") << (bstrURL ? OLE2CT(bstrURL) : _T("")) << endl;
}

STDMETHODIMP CIESink::Invoke(DISPID id, REFIID riid, LCID lcid, WORD wFlags, 
	DISPPARAMS* pdp, VARIANT* pvarResult, EXCEPINFO* pExcepInfo, UINT* puArgErr)
{
	REDIR_OUT2LOG;
	USES_CONVERSION;
	if (!pdp) return E_INVALIDARG;

	switch (id)
	{
		//
		// The parameters for this DISPID are as follows:
		// [0]: Cancel flag  - VT_BYREF|VT_BOOL
		// [1]: HTTP headers - VT_BYREF|VT_VARIANT
		// [2]: Address of HTTP POST data  - VT_BYREF|VT_VARIANT 
		// [3]: Target frame name - VT_BYREF|VT_VARIANT 
		// [4]: Option flags - VT_BYREF|VT_VARIANT
		// [5]: URL to navigate to - VT_BYREF|VT_VARIANT
		// [6]: An object that evaluates to the top-level or frame
		//      WebBrowser object corresponding to the event. 
		//
		case DISPID_BEFORENAVIGATE2:
			ATLASSERT(pdp->cArgs == 7);
			OnBeforeNavigate2(pdp->rgvarg[6].pdispVal,
							  pdp->rgvarg[5].pvarVal,
							  pdp->rgvarg[4].pvarVal,
							  pdp->rgvarg[3].pvarVal,
							  pdp->rgvarg[2].pvarVal,
							  pdp->rgvarg[1].pvarVal,
							  pdp->rgvarg[0].pboolVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: URL navigated to - VT_BYREF|VT_VARIANT
		// [1]: An object that evaluates to the top-level or frame
		//      WebBrowser object corresponding to the event. 
		//
		case DISPID_NAVIGATECOMPLETE2:
			ATLASSERT(pdp->cArgs == 2);
			OnNavigateComplete2(pdp->rgvarg[1].pdispVal,
								pdp->rgvarg[0].pvarVal);

		break;

		//
		// The parameters for this DISPID:
		// [0]: New status bar text - VT_BSTR
		//
		case DISPID_STATUSTEXTCHANGE:
			ATLASSERT(pdp->cArgs == 1);
			OnStatusTextChange(W2CT(pdp->rgvarg[0].bstrVal));
		break;

		//
		// The parameters for this DISPID:
		// [0]: Maximum progress - VT_I4
		// [1]: Amount of total progress - VT_I4
		//
		case DISPID_PROGRESSCHANGE:
			ATLASSERT(pdp->cArgs == 2);
			OnProgressChange(pdp->rgvarg[1].lVal,
							 pdp->rgvarg[0].lVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: URL navigated to - VT_BYREF|VT_VARIANT
		// [1]: An object that evaluates to the top-level or frame
		//      WebBrowser object corresponding to the event. 
		//
		case DISPID_DOCUMENTCOMPLETE:
			ATLASSERT(pdp->cArgs == 2);
			OnDocumentComplete(pdp->rgvarg[1].pdispVal,
							   pdp->rgvarg[0].pvarVal);
		break;

		case DISPID_DOWNLOADBEGIN:
			ATLASSERT(pdp->cArgs == 0);
			OnDownloadBegin();
		break;

		case DISPID_DOWNLOADCOMPLETE:
			ATLASSERT(pdp->cArgs == 0);
			OnDownloadComplete();
		break;

		//
		// The parameters for this DISPID:
		// [0]: Enabled state - VT_BOOL
		// [1]: Command identifier - VT_I4
		//
		case DISPID_COMMANDSTATECHANGE:
			ATLASSERT(pdp->cArgs == 2);
			OnCommandStateChange(pdp->rgvarg[1].lVal,
								 pdp->rgvarg[0].boolVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: Cancel flag  - VT_BYREF|VT_BOOL
		// [1]: An object that evaluates to the top-level or frame
		//      WebBrowser object corresponding to the event. 
		//
		case DISPID_NEWWINDOW2:
			ATLASSERT(pdp->cArgs == 2);
			OnNewWindow2(pdp->rgvarg[1].ppdispVal,
						 pdp->rgvarg[0].pboolVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: URL to navigate to - VT_BSTR
		// [1]: URL Context - VT_BSTR
		// [2]: dwFlag - VT_ULONG
		// [3]: Cancel flag  - VT_BYREF|VT_BOOL
		// [4]: An object that evaluates to the top-level or frame
		//      WebBrowser object corresponding to the event. 
		//
		case DISPID_NEWWINDOW3:
			ATLASSERT(pdp->cArgs == 5);
			OnNewWindow3(pdp->rgvarg[4].ppdispVal,
						 pdp->rgvarg[3].pboolVal,
						 pdp->rgvarg[2].ulVal,
						 pdp->rgvarg[1].bstrVal,
						 pdp->rgvarg[0].bstrVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: Document title - VT_BSTR
		//
		case DISPID_TITLECHANGE:
			ATLASSERT(pdp->cArgs == 1);
			OnTitleChange(W2CT(pdp->rgvarg[0].bstrVal));
		break;

		//
		// The parameters for this DISPID:
		// [0]: Name of property that changed - VT_BSTR
		//
		case DISPID_PROPERTYCHANGE:
			ATLASSERT(pdp->cArgs == 1);
			OnPropertyChange(W2CT(pdp->rgvarg[0].bstrVal));
		break;

		//
		// The parameters for this DISPID:
		// [0]: Address of cancel flag - VT_BYREF|VT_BOOL
		//
		case DISPID_QUIT:
		case DISPID_ONQUIT:
			ATLASSERT(pdp->cArgs == 0);
			OnQuit();
		break;

		//
		// The parameters for this DISPID:
		// [0]: Browser shown/hidden flag - VT_BOOL
		//	
		case DISPID_ONVISIBLE:
			ATLASSERT(pdp->cArgs == 1);
			OnVisible(pdp->rgvarg[0].boolVal);
		break;	

		//
		// The parameters for this DISPID:
		// [0]: Toolbar shown/hidden flag - VT_BOOL
		//	
		case DISPID_ONTOOLBAR:
			ATLASSERT(pdp->cArgs == 1);
			OnToolBar(pdp->rgvarg[0].boolVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: Menubar shown/hidden flag - VT_BOOL
		//	
		case DISPID_ONMENUBAR:
			ATLASSERT(pdp->cArgs == 1);
			OnMenuBar(pdp->rgvarg[0].boolVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: Statusbar shown/hidden flag - VT_BOOL
		//	
		case DISPID_ONSTATUSBAR:
			ATLASSERT(pdp->cArgs == 1);
			OnStatusBar(pdp->rgvarg[0].boolVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: Fullscreen mode on/off flag - VT_BOOL
		//	
		case DISPID_ONFULLSCREEN:
			ATLASSERT(pdp->cArgs == 1);
			OnFullScreen(pdp->rgvarg[0].boolVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: Theater mode on/off flag - VT_BOOL
		//	
		case DISPID_ONTHEATERMODE:
			ATLASSERT(pdp->cArgs == 1);
			OnTheaterMode(pdp->rgvarg[0].boolVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: Host window allow/disallow resizing flag - VT_BOOL
		//	
		case DISPID_WINDOWSETRESIZABLE:
			ATLASSERT(pdp->cArgs == 1);
			OnWindowSetResizable(pdp->rgvarg[0].boolVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: The new left coordinate of the host window change to - VT_I4
		//	
		case DISPID_WINDOWSETLEFT:
			ATLASSERT(pdp->cArgs == 1);
			OnWindowSetLeft(pdp->rgvarg[0].lVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: The new top coordinate of the host window change to - VT_I4
		//	
		case DISPID_WINDOWSETTOP:
			ATLASSERT(pdp->cArgs == 1);
			OnWindowSetTop(pdp->rgvarg[0].lVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: The new width of the host window change to - VT_I4
		//	
		case DISPID_WINDOWSETWIDTH:
			ATLASSERT(pdp->cArgs == 1);
			OnWindowSetWidth(pdp->rgvarg[0].lVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: The new height of the host window change to - VT_I4
		//	
		case DISPID_WINDOWSETHEIGHT:
			ATLASSERT(pdp->cArgs == 1);
			OnWindowSetHeight(pdp->rgvarg[0].lVal);
		break;

		//
		// The parameters for this DISPID:
		// [0]: Cancel flag  - VT_BYREF|VT_BOOL
		// [1]: Is a child window to close me - VT_BOOL
		//	
		case DISPID_WINDOWCLOSING:
			ATLASSERT(pdp->cArgs == 2);
			OnWindowClosing(pdp->rgvarg[1].boolVal, pdp->rgvarg[0].pboolVal);
		break;

		case DISPID_CLIENTTOHOSTWINDOW:
			ATLASSERT(pdp->cArgs == 2);
			OnClientToHostWindow(pdp->rgvarg[1].plVal, pdp->rgvarg[0].plVal);
		break;

		case DISPID_SETSECURELOCKICON:
			ATLASSERT(pdp->cArgs == 1);
			OnSetSecureLockIcon(pdp->rgvarg[0].lVal);
		break;
/*
		case DISPID_FILEDOWNLOAD:
			ATLASSERT(pdp->cArgs == 1);
			OnFileDownload(pdp->rgvarg[0].pboolVal);
		break;
*/
		case DISPID_NAVIGATEERROR:
			ATLASSERT(pdp->cArgs == 5);
			OnNavigateError(pdp->rgvarg[4].pdispVal, 
							pdp->rgvarg[3].pvarVal,
							pdp->rgvarg[2].pvarVal,
							pdp->rgvarg[1].pvarVal,
							pdp->rgvarg[0].pboolVal);
		break;
		
		case DISPID_PRINTTEMPLATEINSTANTIATION:
			ATLASSERT(pdp->cArgs == 1);
			OnPrintTemplateInstantiation(pdp->rgvarg[0].pdispVal);
		break;
		
		case DISPID_PRINTTEMPLATETEARDOWN:
			ATLASSERT(pdp->cArgs == 1);
			OnPrintTemplateTeardown(pdp->rgvarg[0].pdispVal);
		break;
		
		case DISPID_UPDATEPAGESTATUS:
			ATLASSERT(pdp->cArgs == 3);
			OnUpdatePageStatus(pdp->rgvarg[2].pdispVal,
							   pdp->rgvarg[1].pvarVal,
							   pdp->rgvarg[0].pvarVal);
		break;

		case DISPID_PRIVACYIMPACTEDSTATECHANGE:
			ATLASSERT(pdp->cArgs == 1);
			OnPrivacyImpactedStateChange(pdp->rgvarg[0].boolVal);
		break;

		default:
			cout
				<< _T("CIESink::Invoke unknown event: ")
				<< _T("dispID = ") << id
				<< _T(", pParams = [");
			for (int i = 0; i < pdp->cArgs; i++)
			{
				cout << pdp->rgvarg[i].bstrVal << _T(", ");
			}
			cout << "]" << endl;
		break;
	}
	REDIR_OUT2OUT;
	return S_OK;
}

// DWebBrowserEvents2 methods
// Fired before navigate occurs in the given WebBrowser (window or frameset element). 
// The processing of this navigation may be modified.
void CIESink::OnBeforeNavigate2(LPDISPATCH pDisp,
			 				   VARIANT* URL,
							   VARIANT* Flags,
							   VARIANT* TargetFrameName,
							   VARIANT* PostData,
							   VARIANT* Headers,
							   VARIANT_BOOL* Cancel)
{
	cout << "CIESink::OnBeforeNavigate2" << endl;
}

// Fired when the document being navigated to becomes visible and enters the navigation stack.
void CIESink::OnNavigateComplete2(LPDISPATCH pDisp, VARIANT* URL)
{
	cout << "CIESink::OnNavigateComplete" << endl;
}

// Statusbar text changed.
void CIESink::OnStatusTextChange(LPCTSTR Text)
{
	cout << "CIESink::OnStatusTextChange" << endl;
}

// Fired when download progress is updated.
void CIESink::OnProgressChange(long Progress, long ProgressMax)
{
	cout << "CIESink::OnProgressChange" << endl;
}

// Fired when the document being navigated to reaches ReadyState_Complete.
void CIESink::OnDocumentComplete(LPDISPATCH pDisp, VARIANT *pvarURL)
{
	cout << "CIESink::OnDocumentComplete" << endl;
	CComQIPtr<IWebBrowser2> pWebBrowser2 = pDisp;
	HRESULT hr = S_FALSE;
	if(pWebBrowser2)
	{
		CComPtr<IDispatch> spDispDoc;
		hr = pWebBrowser2->get_Document(&spDispDoc);
		if (SUCCEEDED(hr) && spDispDoc) 
		{
			CComQIPtr<IHTMLDocument2> spDocument = spDispDoc;
			EnumDocument(spDocument);
		}
	}
}

// Download of a page started.
void CIESink::OnDownloadBegin()
{
	cout << "CIESink::OnDownloadBegin" << endl;
}

// Download of page complete.
void CIESink::OnDownloadComplete()
{
	cout << "CIESink::OnDownloadComplete" << endl;
}

// The enabled state of a command changed.
void CIESink::OnCommandStateChange(long Command, BOOL Enable)
{
	cout << "CIESink::OnCommandStateChange" << endl;
}

// A new, hidden, non-navigated WebBrowser window is needed.
void CIESink::OnNewWindow2(LPDISPATCH* ppDisp, VARIANT_BOOL* Cancel)
{
	cout << "CIESink::OnNewWindow2" << endl;
}

// A new, hidden, non-navigated WebBrowser window is needed.
void CIESink::OnNewWindow3(LPDISPATCH* ppDisp, VARIANT_BOOL* Cancel, unsigned long dwFlags, 
	BSTR bstrUrlContext, BSTR bstrUrl)
{
	cout << "CIESink::OnNewWindow3" << endl;
}

// Document title changed.
void CIESink::OnTitleChange(LPCTSTR Text)
{
	cout << "CIESink::OnTitleChange" << endl;
}

// Fired when the PutProperty method has been called.
void CIESink::OnPropertyChange(LPCTSTR szProperty)
{
	cout << "CIESink::OnPropertyChange" << endl;
}

// Fired when application is quiting.
void CIESink::OnQuit()
{
	cout << "CIESink::OnQuit" << endl;
}

// Fired when the window should be shown/hidden.
void CIESink::OnVisible(VARIANT_BOOL Visible)
{
	cout << "CIESink::OnVisible" << endl;
}

// Fired when the toolbar  should be shown/hidden.
void CIESink::OnToolBar(VARIANT_BOOL ToolBar)
{
	cout << "CIESink::OnToolBar" << endl;
}

// Fired when the menubar should be shown/hidden.
void CIESink::OnMenuBar(VARIANT_BOOL MenuBar)
{
	cout << "CIESink::OnMenuBar" << endl;
}

// Fired when the statusbar should be shown/hidden.
void CIESink::OnStatusBar(VARIANT_BOOL StatusBar)
{
	cout << "CIESink::OnStatusBar" << endl;
}

// Fired when fullscreen mode should be on/off.
void CIESink::OnFullScreen(VARIANT_BOOL FullScreen)
{
	cout << "CIESink::OnFullScreen" << endl;
}

// Fired when theater mode should be on/off.
void CIESink::OnTheaterMode(VARIANT_BOOL TheaterMode)
{
	cout << "CIESink::OnTheaterMode" << endl;
}

// Fired when the host window should allow/disallow resizing.
void CIESink::OnWindowSetResizable(VARIANT_BOOL Resizable)
{
	cout << "CIESink::OnWindowSetResizable" << endl;
}

// Fired when the host window should change its Left coordinate.
void CIESink::OnWindowSetLeft(long Left)
{
	cout << "CIESink::OnWindowSetLeft" << endl;
}

// Fired when the host window should change its Top coordinate.
void CIESink::OnWindowSetTop(long Top)
{
	cout << "CIESink::OnWindowSetTop" << endl;
}

// Fired when the host window should change its width.
void CIESink::OnWindowSetWidth(long Width)
{
	cout << "CIESink::OnWindowSetWidth" << endl;
}

// Fired when the host window should change its height.
void CIESink::OnWindowSetHeight(long Height)
{
	cout << "CIESink::OnWindowSetHeight" << endl;
}

// Fired when the WebBrowser is about to be closed by script.
void CIESink::OnWindowClosing(VARIANT_BOOL IsChildWindow, VARIANT_BOOL* Cancel)
{
	cout << "CIESink::OnWindowClosing" << endl;
}

// Fired to request client sizes be converted to host window sizes.
void CIESink::OnClientToHostWindow(long* CX, long* CY)
{
	cout << "CIESink::OnClientToHostWindow" << endl;
}

// Fired to indicate the security level of the current web page contents.
void CIESink::OnSetSecureLockIcon(long SecureLockIcon)
{
	cout << "CIESink::OnSetSecureLockIcon" << endl;
}

// Fired to indicate the File Download dialog is opening.
void CIESink::OnFileDownload(VARIANT_BOOL* Cancel)
{
	cout << "CIESink::OnFileDownload" << endl;
}

// Fired when a binding error occurs (window or frameset element).
void CIESink::OnNavigateError(LPDISPATCH pDisp, VARIANT* URL, VARIANT* Frame, 
	VARIANT* StatusCode, VARIANT_BOOL* Cancel)
{
	cout << "CIESink::OnNavigateError" << endl;
}

// Fired when a print template is instantiated.
void CIESink::OnPrintTemplateInstantiation(LPDISPATCH pDisp)
{
	cout << "CIESink::OnPrintTemplateInstantiation" << endl;
}

// Fired when a print template destroyed."
void CIESink::OnPrintTemplateTeardown(LPDISPATCH pDisp)
{
	cout << "CIESink::OnPrintTemplateTeardown" << endl;
}

// Fired when a page is spooled. When it is fired can be changed by a custom template.
void CIESink::OnUpdatePageStatus(LPDISPATCH pDisp, VARIANT* nPage, VARIANT* fDone)
{
	cout << "CIESink::OnUpdatePageStatus" << endl;
}

// Fired when the global privacy impacted state changes.
void CIESink::OnPrivacyImpactedStateChange(VARIANT_BOOL bImpacted)
{
	cout << "CIESink::OnPrivacyImpactedStateChange" << endl;
}
