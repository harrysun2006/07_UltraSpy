#include "StdAfx.h"
#include "MainDlg.h"
#include "Test.h"
#include "FlashSink3.h"
#include "Flash9d.tlh"

#include <mshtml.h>
#include <map>
#include <string>

using namespace std;
using namespace ShockwaveFlashObjects;

void test1()
{
	IWebBrowser2 *m_pInternetExplorer; 
	CoCreateInstance(CLSID_InternetExplorer,NULL,CLSCTX_SERVER,IID_IWebBrowser2,(LPVOID *)&m_pInternetExplorer);
	m_pInternetExplorer->put_Visible(VARIANT_TRUE);

	BSTR Url,Target,PostData,Head;
	VARIANT BstrUrl,BstrTarget,IFlag,BstrPostData,BstrHead;
	V_VT(&BstrUrl)=VT_BSTR;
	V_BSTR(&BstrUrl)=Url=SysAllocString(L"http://www.google.com");
	V_VT(&BstrTarget)=VT_BSTR;
	V_BSTR(&BstrTarget)=Target=SysAllocString(L"_self");
	V_VT(&BstrPostData)=VT_BSTR;
	V_BSTR(&BstrPostData)=PostData=SysAllocString(L"");
	V_VT(&BstrHead)=VT_BSTR;
	V_BSTR(&BstrHead)=Head=SysAllocString(L"");
	V_VT(&IFlag)=VT_I4;
	V_I4(&IFlag)=navNoHistory;

	m_pInternetExplorer->Navigate2(&BstrUrl,&IFlag,&BstrTarget,&BstrPostData,&BstrHead);
	SysFreeString(Url);
	SysFreeString(Target);
	SysFreeString(PostData);
	SysFreeString(Head);
	//MonitorWebBrowser(m_pInternetExplorer);
	m_pInternetExplorer->Release();
}

void test2()
{
	LPOLESTR name = NULL;
	StringFromIID(DIID_DWebBrowserEvents2, &name);
	USES_CONVERSION;
	g_pMainWin->Log(OLE2CT(name));
}

void test3()
{
	typedef map<string, string>maps;
	typedef pair<string, string>pr;
	maps temp;
	temp.insert(pr("aa","aaaaa"));
	temp.insert(pr("bb","bbbbbb"));
	temp.insert(pr("cc","cccc"));
	maps   tent;
	maps::iterator   it;
	for(it = temp.begin(); it != temp.end(); ++it) tent.insert(*it);
	for(it = tent.begin(); it != tent.end(); ++it)
	{
		cout << (*it).first << "   " << (*it).second << endl;
	}
}

void test4()
{
	CFlashSink3* sink = new CFlashSink3();
	IDispatch* pDisp = NULL;
	HRESULT hr = sink->QueryInterface(DIID__IShockwaveFlashEvents, reinterpret_cast<void**>(&pDisp));
	if (SUCCEEDED(hr) && pDisp) cout << "CFlashSink3::_IShockwaveFlashEvents found" << endl;
	else cout << "CFlashSink3::_IShockwaveFlashEvents NOT found!" << endl;
}